__NUXT_JSONP__("/", {
    data: [{}],
    fetch: {},
    mutations: []
});